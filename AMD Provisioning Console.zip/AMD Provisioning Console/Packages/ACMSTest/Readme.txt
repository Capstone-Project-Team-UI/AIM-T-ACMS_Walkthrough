README: 

AIM-T
	Steps to Provision an AIM-T board.
		Step-1: Copy the "<PackageName>/AIM-T" folder created from this tool to AIM-T supported board which needs provisioning.
		Step-2: Open command prompt in administrative mode.
		Step-3: Go to "<PackageName>/AIM-T" folder copied at Step-1 and execute below command:
			$ AIM-TProvisioningApp.exe -i <CryptoName>_<PackageName>_oMt.
			- Above command provisions the AIM-T supported system with <CryptoName>_<PackageName>_oMt AEPP file.

	Note:
	1. Ot and oMt packages should be used only in Trusted environment as it contains un-encrypted cryptographic key. M package can be used in trusted or untrusted environment.
	2. <PackageName> - Refers to package name given in the Package section of UI.
		A folder will be created under secured path (selected by under Configurations section of UI) with this package name to store all the files generated from this tool.
		Example: if user has selected "C:\APC_Path" as secured path and package name is given as "AMD_BLR_Package" then path to package folder will be "C:\APC_Path\AMD_BLR_Package".
	3. <CryptoName>_<PackageName>_oMt - Refers to Crypto name chosen by user in Package section.
		Example: If Crypto name selected is "AMD_BLR_CRYPTO" and package name is given as "AMD_BLR_Package" then AEPP filename will be "AMD_BLR_CRYPTO_AMD_BLR_Package_oMt"
		Command to provision as per the above example: $ AIM-TProvisioningApp.exe -i AMD_BLR_CRYPTO_AMD_BLR_Package_oMt.

	For more information related to Files generated from this tool refer to "Release Notes" under docs folder in AMD Provisioning Console installation path.

Cloud
	Refer AMD Cloud Manageability Service (ACMS) document for installing Server, Console, Managed system certificates.

Realtek
	Steps to Provision a Realtek board,
		Step-1: Copy "<PackageName>/RealtekConfig" folder created from this tool to Realtek Wired board.
		Step-2: Open command prompt in administrative mode.
		Step-3: DASHConfigRT.exe -xf:DashConfig.xml.

Marvel
	Steps to Provision a Marvel board,
		Step-1: Copy "<PackageName>/MarvelConfig" folder created from this tool to Marvel Wired board.
		Step-2: Open command prompt in administrative mode.
		Step-3: Marvel board can be Provisioned in either Exclusive or Shared mode.
		For Provisioning in Shared mode:  Run Shared.bat.
		For Provisioning in Exclusive mode: Update Mac Address and IP address in the Exclusive.bat file and Run Exclusive.bat.

Broadcom
	Steps to Provision a Broadcom board,
		Step-1: Copy "<PackageName>/BroadcomConfig" folder created from this tool to Broadcom Wired board.
		Step-2: Open command prompt in administrative mode.
		Step-3: DASHConfig.exe -xf:DashConfig.xml.
